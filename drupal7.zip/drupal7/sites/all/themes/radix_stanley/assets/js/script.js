/**
 * @file
 * Custom scripts for theme.
 */
(function ($) {
  $(document).ready(function() {
    $('.blue').hoverZoom({
        overlayColor: '#3498db',
        zoom: 0
    });
    
    $('.green').hoverZoom({
        overlayColor: '#1abc9c',
        zoom: 0
    });
    
    $('.pink').hoverZoom({
        overlayColor: '#bd2e75',
        zoom: 0
    });
    
    $('.black').hoverZoom({
        overlayColor: '#2f2f2f',
        zoom: 0
    });
    
    $('.alizarin').hoverZoom({
        overlayColor: '#e74c3c',
        zoom: 0
    });
  });
})(jQuery);
