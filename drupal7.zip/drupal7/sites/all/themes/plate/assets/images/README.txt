
This directory should be used to place images for your theme.
