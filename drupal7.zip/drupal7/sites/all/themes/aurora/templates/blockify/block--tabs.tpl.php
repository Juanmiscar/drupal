<div id="tabs">
  <?php print $tabs; ?>
</div>