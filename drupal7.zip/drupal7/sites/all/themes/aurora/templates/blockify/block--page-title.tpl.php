<h1 id="page-title" class="title">
  <?php print $page_title; ?>
</h1>
