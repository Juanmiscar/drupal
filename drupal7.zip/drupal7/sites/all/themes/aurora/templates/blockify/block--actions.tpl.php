<?php if (!empty($actions)): ?>
  <ul class="action-links">
    <?php print render($actions); ?>
  </ul>
<?php endif; ?>