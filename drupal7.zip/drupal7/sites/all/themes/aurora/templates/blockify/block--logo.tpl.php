<span id="logo">
  <a href="<?php print $sitepath; ?>" title="<?php print $sitename; ?>" rel="home">
    <?php print render($logo); ?>
  </a>
</span>
