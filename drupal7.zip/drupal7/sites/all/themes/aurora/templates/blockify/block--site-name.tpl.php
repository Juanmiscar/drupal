<span id="site-name">
  <a href="<?php print $sitepath; ?>" title="<?php print $sitename; ?>" rel="home">
    <h1>
      <?php print $sitename; ?>
    </h1>
  </a>
</span>
