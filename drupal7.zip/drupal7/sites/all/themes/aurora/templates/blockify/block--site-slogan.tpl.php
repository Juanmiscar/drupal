<span id="site-slogan">
  <?php print $slogan; ?>
</span>